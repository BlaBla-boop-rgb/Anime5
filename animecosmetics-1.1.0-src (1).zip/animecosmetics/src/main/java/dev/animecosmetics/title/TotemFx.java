package dev.animecosmetics.title;

import dev.animecosmetics.Toggles;
import net.minecraft.client.Minecraft;

/** When your totem pops: the "Death Can't Die" title instead of the floating totem. */
public final class TotemFx {
   private static boolean hideVanilla;

   private TotemFx() {
   }

   public static void register() {
      TotemTitle.register();
   }

   public static void onTotem(Minecraft mc) {
      if (Toggles.get(Toggles.Feature.TOTEM_TITLE)) {
         TotemTitle.play();
         hideVanilla = true;
      }
   }

   public static void tick(Minecraft mc) {
      if (hideVanilla) {
         hideVanilla = false;
         if (mc.player != null) {
            // the title takes the centre of the screen, so the floating totem is left out
            mc.player.itemActivation().reset();
         }
      }
   }

   public static void clear() {
      hideVanilla = false;
      TotemTitle.clear();
   }
}
