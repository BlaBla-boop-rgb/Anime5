package dev.animecosmetics.fx;

import dev.animecosmetics.AnimeCosmetics;
import dev.animecosmetics.Toggles;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * "Kill-Animation": what you kill crumbles to ash (Ronova's AshDeath).
 *
 * The client does not know who killed a mob, so this remembers what you hit yourself: if it dies within
 * a few seconds of your last hit, it turns to ash. When the body disappears, a cloud of ash and embers is left.
 */
public final class KillFx {
   /** Seconds after your last hit in which a death still counts as your kill. */
   private static final float HIT_WINDOW = 4.0F;
   private static final SoundEvent SOUND_ASH = SoundEvent.createFixedRangeEvent(AnimeCosmetics.id("ash"), 24.0F);
   private static final RandomSource SOUND_RND = RandomSource.create();
   private static final DustParticleOptions EMBER = new DustParticleOptions(0xFF4A28, 0.8F);
   private static final DustParticleOptions CINDER = new DustParticleOptions(0x2A2422, 1.4F);
   private static final Random RND = new Random();
   /** Entity id -> time of your last hit. */
   private static final Map<Integer, Long> HITS = new HashMap<>();
   /** Entity id -> last known body (centre, width, height) of a mob that is turning to ash. */
   private static final Map<Integer, double[]> BURNING = new HashMap<>();

   private KillFx() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level.isClientSide() && player == mc.player && entity instanceof LivingEntity) {
            HITS.put(entity.getId(), System.nanoTime());
         }

         return InteractionResult.PASS;
      });
   }

   public static void clear() {
      HITS.clear();
      BURNING.clear();
      AshDeath.clear();
   }

   public static void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null) {
         return;
      }

      long now = System.nanoTime();
      boolean on = Toggles.get(Toggles.Feature.KILL_FX);
      Iterator<Map.Entry<Integer, Long>> it = HITS.entrySet().iterator();

      while (it.hasNext()) {
         Map.Entry<Integer, Long> e = it.next();
         Entity entity = mc.level.getEntity(e.getKey());
         if ((float)(now - e.getValue()) / 1.0E9F > HIT_WINDOW || entity == null) {
            it.remove();
         } else if (entity instanceof LivingEntity le && le.isDeadOrDying()) {
            it.remove();
            if (on && entity != mc.player) {
               AshDeath.start(entity.getId());
               BURNING.put(entity.getId(), body(entity));
               mc.getSoundManager()
                  .play(
                     new SimpleSoundInstance(
                        SOUND_ASH, SoundSource.PLAYERS, 0.6F, 0.95F + SOUND_RND.nextFloat() * 0.1F, SOUND_RND, entity.getX(), entity.getY(), entity.getZ()
                     )
                  );
            }
         }
      }

      Iterator<Map.Entry<Integer, double[]>> bt = BURNING.entrySet().iterator();

      while (bt.hasNext()) {
         Map.Entry<Integer, double[]> e = bt.next();
         Entity entity = mc.level.getEntity(e.getKey());
         if (entity != null && !entity.isRemoved()) {
            double[] b = body(entity);
            e.setValue(b);
            // embers rising from the cracks while it burns
            for (int i = 0; i < 3; i++) {
               spawn(mc, b, EMBER, 0.02 + RND.nextDouble() * 0.05);
            }
         } else {
            // the body is gone: leave a cloud of ash and embers
            double[] b = e.getValue();
            int n = (int)Math.min(80.0, 18.0 + b[3] * b[4] * 30.0);

            for (int i = 0; i < n; i++) {
               spawn(mc, b, i % 3 == 0 ? EMBER : CINDER, 0.01 + RND.nextDouble() * 0.04);
            }

            for (int i = 0; i < n / 3; i++) {
               spawn(mc, b, ParticleTypes.LARGE_SMOKE, 0.01 + RND.nextDouble() * 0.03);
            }

            AshDeath.end(e.getKey());
            bt.remove();
         }
      }
   }

   private static double[] body(Entity e) {
      return new double[]{e.getX(), e.getY(), e.getZ(), e.getBbWidth(), e.getBbHeight()};
   }

   private static void spawn(Minecraft mc, double[] b, net.minecraft.core.particles.ParticleOptions type, double up) {
      double w = b[3];
      double x = b[0] + (RND.nextDouble() - 0.5) * w;
      double y = b[1] + RND.nextDouble() * b[4];
      double z = b[2] + (RND.nextDouble() - 0.5) * w;
      Vec3 v = new Vec3((RND.nextDouble() - 0.5) * 0.04, up, (RND.nextDouble() - 0.5) * 0.04);
      mc.level.addParticle(type, x, y, z, v.x, v.y, v.z);
   }
}
